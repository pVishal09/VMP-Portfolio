<?php
if (isset($_POST["submit"])) {
    $name = htmlspecialchars(trim($_POST['name']));
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $message = htmlspecialchars(trim($_POST['message']));
    $subject = htmlspecialchars(trim($_POST['subject']));
    
    $to = 'pvishu8go@gmail.com';
    $headers = "From: $email\r\nReply-To: $email\r\nContent-Type: text/plain; charset=UTF-8";

    $body = "From: $name\nE-Mail: $email\nSubject: $subject\nMessage:\n$message";

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        if (mail($to, $subject, $body, $headers)) {
            header("Location: thank-you.html");
            exit();
        } else {
            echo "Error! Email could not be sent.";
        }
    } else {
        echo "Invalid email address!";
    }
}
?>
